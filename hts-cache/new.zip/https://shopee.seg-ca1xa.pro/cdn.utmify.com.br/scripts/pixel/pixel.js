<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"
  "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" lang="en" xml:lang="en">
<head>
<title>Object not found!</title>
<link rev="made" href="mailto:postmaster@localhost" />
<style type="text/css"><!--/*--><![CDATA[/*><!--*/ 
    body { color: #000000; background-color: #FFFFFF; }
    a:link { color: #0000CC; }
    p, address {margin-left: 3em;}
    span {font-size: smaller;}
/*]]>*/--></style>
</head>

<body>
<h1>Object not found!</h1>
<p>


    The requested URL was not found on this server.

  

    The link on the
    <a href="https://shopee.seg-ca1xa.pro/5mil/log.html">referring
    page</a> seems to be wrong or outdated. Please inform the author of
    <a href="https://shopee.seg-ca1xa.pro/5mil/log.html">that page</a>
    about the error.

  

</p>
<p>
If you think this is a server error, please contact
the <a href="/cdn-cgi/l/email-protection#3c4c534f48515d4f48594e7c50535f5d5054534f48">webmaster</a>.

</p>

<h2>Error 404</h2>
<address>
  <a href="/">shopee.seg-ca1xa.pro</a><br />
  <span>Apache/2.4.46 (Win64) OpenSSL/1.1.1g PHP/7.4.9</span>
</address>
<script data-cfasync="false" src="/cdn-cgi/scripts/5c5dd728/cloudflare-static/email-decode.min.js"></script></body>
</html>

